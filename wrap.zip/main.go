package main

import (
	"log"
	"net/http"

	"github.com/pseidemann/finish"
	"github.com/sinakeshmiri/arun-wrp/packages/function"
)
func wrp(w http.ResponseWriter, req *http.Request) {
	function.Function(w,req)
	fin.Trigger()
}
var fin *finish.Finisher
func main() {
	http.HandleFunc("/", wrp)

	srv := &http.Server{Addr: ":80"}

	fin = finish.New()
	fin.Add(srv)
	go func() {
		err := srv.ListenAndServe()
		if err != http.ErrServerClosed {
			log.Fatal(err)
		}
	}()

	fin.Wait()
}
