package main

import (
	"fmt"
	"net/http"
	"os"
	"time"

	"github.com/sinakeshmiri/arun-wrp/packages/function"
)

var elapsed time.Duration

func healthz(w http.ResponseWriter, req *http.Request) {

	fmt.Fprintf(w, "{'status':'true'}")
}

func headers(w http.ResponseWriter, req *http.Request) {
	start := time.Now()
	function.Function(w, req)
	elapsed = time.Since(start)
}

func timeCalc(w http.ResponseWriter, req *http.Request) {

	fmt.Fprintf(w, fmt.Sprintf("{'duration':'%s'}", elapsed))

}
func die(w http.ResponseWriter, req *http.Request) {

	defer os.Exit(0)

}

func main() {
	http.HandleFunc("/healthz", healthz)
	http.HandleFunc("/function", headers)
	http.HandleFunc("/time", timeCalc)
	http.HandleFunc("/die", die)
	http.ListenAndServe(":80", nil)
}
