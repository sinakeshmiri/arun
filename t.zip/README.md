# goraz

this application helps you to bypass diffrent  CDN/WAFs like CF , ARVAN , ... by finding the protected ip address

  ```
  git clone https://github.com/sinakeshmiri/goraz
  cd goraz
  nano config #add your target and keys
  go run main.go
  #output : guessed ip addresses 
```
  #to do:
  - cleaner code
  - concurrency support
  - add more DBs
 
  
